# Tharun AI Academy

A multi-page static website created as a student web-design portfolio project for Tharun Gowda G.

## Publish
Upload these files to a static hosting service such as GitHub Pages or Netlify. The site needs no server or database.

## Pages
- index.html — home
- courses.html — learning paths
- practice.html — coding practice
- style.css — responsive design
- script.js — dark mode and interactions

## YouTube
The site uses links to public YouTube search results. Do not download/re-upload someone else's videos without permission. Add official video links or embeds when you have permission or when the video creator provides an embeddable video.

## Customize
Change the content, add your own lessons, add project pages, and eventually add your own YouTube channel.
