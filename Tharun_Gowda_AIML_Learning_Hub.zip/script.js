const themeBtn = document.getElementById("themeBtn");
const savedTheme = localStorage.getItem("tg-theme");
if (savedTheme === "dark") document.body.classList.add("dark");

function updateThemeIcon() {
  themeBtn.textContent = document.body.classList.contains("dark") ? "☀️" : "🌙";
}
updateThemeIcon();

themeBtn.addEventListener("click", () => {
  document.body.classList.toggle("dark");
  localStorage.setItem("tg-theme", document.body.classList.contains("dark") ? "dark" : "light");
  updateThemeIcon();
});

document.getElementById("answerBtn").addEventListener("click", () => {
  const answer = document.getElementById("answer");
  answer.classList.toggle("hidden");
  document.getElementById("answerBtn").textContent =
    answer.classList.contains("hidden") ? "Show Python answer" : "Hide Python answer";
});
